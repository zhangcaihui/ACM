#include<cstdio>
#include<cstring>
const int maxn = 1001010;
char str[maxn], all[233], ch[maxn];
int ff, len, T, mp[2333];
void puin(){
    scanf("%s%s", all, str+1);
    for(int i = 1; str[i]; i ++)
        if(str[i] == '*')
            ff = 1;
    for(int i = 0; all[i]; i ++) mp[all[i]] ++;
    scanf("%d", &T);
    len = strlen(str+1);
}
void proc(){
    scanf("%s", ch+1);
    int tem = strlen(ch+1), ans = 1;
    if(!ff){
        if(tem != len)
            ans = 0;
        for(int i = 1; i <= len && ans; i ++){
            if(str[i] == '?'){
                if(mp[ch[i]])
                    continue;
                ans = 0;
            }
            if(ch[i] != str[i])
                ans = 0;
        }
    }
    else{
        int p1 = 0, p2 = tem + 1;
        for(int i = 1; str[i] != '*' && ans; i ++){
            p1 = i;
            if(str[i] == '?'){
                if(mp[ch[i]])
                    continue;
                ans = 0;
            }
            if(ch[i] != str[i])
                ans = 0;
        }
        for(int i = len; str[i] != '*' && ans; i --){
            p2 = tem+i-len;
            if(str[i] == '?'){
                if(mp[ch[tem+i-len]])
                    continue;
                ans = 0;
            }
            if(ch[tem+i-len] != str[i])
                ans = 0;
        }
        if(p1 >= p2)
            ans = 0;
        for(int i = p1+1; i < p2 && ans; i ++){
            if(mp[ch[i]])
                ans = 0;
        }
        //printf("p1 = %d \t p2 = %d\n", p1, p2);
    }
    if(ans)
        printf("YES\n");
    else
        printf("NO\n");
}

int main(){
    puin();
    while(T--)
        proc();
}
